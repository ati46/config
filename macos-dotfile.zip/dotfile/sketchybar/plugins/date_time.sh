#!/usr/bin/env bash

#sketchybar -m --set $NAME label="$(date '+%a %d %b %H:%M')"
sketchybar -m --set $NAME label="$(date '+%Y-%m-%d')"
