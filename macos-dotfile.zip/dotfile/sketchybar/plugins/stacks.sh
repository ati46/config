array=$(yabai -m query --spaces --space | jq .windows | jq '.[]')
focused=$(yabai -m query --windows --space | jq '.[] | {id:.id,focused:."has-focus"} | select(.focused) | .id')
stacks=""
for element in ${array[@]}
do
	echo $element
	temp="  "
	if [[ $element == $focused ]] ; then
		echo "11"
		temp="  "
	fi
	stacks="$stacks$temp"
done
echo $stacks
#sketchybar -m --set $NAME label="$stacks"
sketchybar -m --set stacks icon="$stacks" label=""
