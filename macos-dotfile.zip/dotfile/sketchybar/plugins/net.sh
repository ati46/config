LABEL=$(/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport -I | awk 'NR==13 {print $2}')
#IP=$(ifconfig | grep "inet " | grep -v 127.0.0.1 | awk -F "[: ]+" '{print $2}' | head -n1)
IP=$(ifconfig | grep "inet " | grep -v 127.0.0.1 | awk -F "[: ]+" '{print $2}')

sketchybar -m --set $NAME label="$LABEL  $IP"