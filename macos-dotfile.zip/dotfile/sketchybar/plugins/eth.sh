#!/usr/bin/env bash

python3 ~/.config/sketchybar/plugins/eth.py
