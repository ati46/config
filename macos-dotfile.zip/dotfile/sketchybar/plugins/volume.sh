LABEL=$(osascript -e 'output volume of (get volume settings)')%

sketchybar -m --set $NAME label=$LABEL