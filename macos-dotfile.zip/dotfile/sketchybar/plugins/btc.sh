#!/usr/bin/env bash

python3 ~/.config/sketchybar/plugins/btc.py
