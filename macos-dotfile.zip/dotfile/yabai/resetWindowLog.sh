#!/bin/bash
#text=$(yabai -m query --windows | jq -r '.[]' | jq '{key:.id|tostring,value:.space}')
text=$(/opt/homebrew/Cellar/yabai/HEAD-a4030e7/bin/yabai -m query --windows | /opt/homebrew/Cellar/jq/1.6/bin/jq '.[]' | /opt/homebrew/Cellar/jq/1.6/bin/jq '{(.id|tostring):(.space)}')
aa=$(echo "$text" | tr -s "\n" " ")
aa=$(echo "$aa" | sed 's/} {/,/g')
echo $aa > /Users/hb21426/.config/yabai/windowLog.json
#maptext=$(echo [$text] | jq 'from_entries')
#data=$(jq . /Users/hb21426/.config/yabai/windowLog.json)
#windows=$(yabai -m query --windows)
#index=( $(echo $windows | jq '.[] | select(.id=='${YABAI_WINDOW_ID}')' | jq '.space'))
#log=$(jq '. + {"'${YABAI_WINDOW_ID}'":'${index}'}' <<< "${data}")
#if [ "$log" = "" ]; then
#	#echo "{}" > /Users/hb21426/.config/yabai/windowLog.json
#	echo "";
#else
#	echo ${log} > /Users/hb21426/.config/yabai/windowLog.json
#fi
