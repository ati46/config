#!/bin/bash
data=$(jq . /Users/hb21426/.config/yabai/windowLog.json)
windows=$(yabai -m query --windows)
index=( $(echo $windows | jq '.[] | select(.id=='${YABAI_WINDOW_ID}')' | jq '.space'))
log=$(jq '. + {"'${YABAI_WINDOW_ID}'":'${index}'}' <<< "${data}")
if [ "$log" = "" ]; then
	#echo "{}" > /Users/hb21426/.config/yabai/windowLog.json
	echo "";
else
	echo ${log} > /Users/hb21426/.config/yabai/windowLog.json
fi
