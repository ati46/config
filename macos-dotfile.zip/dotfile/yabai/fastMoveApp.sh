#!/bin/bash
ids=$(/opt/homebrew/Cellar/yabai/HEAD-a4030e7/bin/yabai -m query --windows | /opt/homebrew/Cellar/jq/1.6/bin/jq -r '.[].id')
ids=($(awk -v RS=' ' '!a[$1]++' <<< ${ids[@]}))
for id in ${ids[@]}; do
{
	space=$(/opt/homebrew/Cellar/jq/1.6/bin/jq '."'$id'"' /Users/hb21426/.config/yabai/windowLog.json)
	if [ "$space" = "null" ]; then
		echo "null";
	else
		/opt/homebrew/Cellar/yabai/HEAD-a4030e7/bin/yabai -m window ${id} --space ${space}
		echo $id
	fi
}
done
echo "done"
#/Users/hb21426/.config/yabai/resetWindowLog.sh
