#!/bin/bash
sh /Users/hb21426/.config/yabai/fastMoveApp.sh
