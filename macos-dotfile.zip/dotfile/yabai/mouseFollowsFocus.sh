#!/usr/bin/env bash
index=$(yabai -m query --spaces --space | jq .index)
if [ $index == 5 ]; then
	yabai -m config focus_follows_mouse off
	yabai -m config window_topmost off
else
	yabai -m config focus_follows_mouse autofocus
	yabai -m config window_topmost on
fi
